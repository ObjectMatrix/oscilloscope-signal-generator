# Simple OTA example

This example is based on `esp_https_ota` component's APIs.

## Configuration

Refer README.md in the parent directory for setup details
